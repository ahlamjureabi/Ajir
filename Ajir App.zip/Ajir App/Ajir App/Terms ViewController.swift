//
//  Terms ViewController.swift
//  Ajir App
//
//  Created by Ahlam Ahlam on 23/05/1443 AH.
//

import UIKit
//import Firebase

class Terms_ViewController: UIViewController {

//    @IBOutlet weak var checkBox: UIButton!
    
}
