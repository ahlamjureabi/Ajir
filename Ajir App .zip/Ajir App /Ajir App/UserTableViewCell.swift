//
//  UserTableViewCell.swift
//  Ajir App
//
//  Created by Ahlam Ahlam on 24/05/1443 AH.
//

import Foundation
import UIKit
import Firebase

class UsreTableViewCell :UITableView {
    
    
    
    
    
}
