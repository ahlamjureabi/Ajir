//
//  cellTableViewCell.swift
//  Ajir App
//
//  Created by Ahlam Ahlam on 10/06/1443 AH.
//

import UIKit
import Firebase

class cellTableViewCell: UITableViewCell {
//
}
//
//
//    @IBOutlet weak var imageCell: UIImageView!
//
//
//
//
//    func configure(with post:Post) -> UITableViewCell {
////       imageCell.text = post.title
////        postDescriptionLabel.text = post.description
//       imageCell.loadImageUsingCache(with: post.user.imageUrl)
////        postImageView.loadImageUsingCache(with: post.imageUrl)
////        postPhoneNumberLabel.text = post.phone
//        return self
//    }
//
//    override func prepareForReuse() {
//        imageCell    .image = nil
////        postImageView.image = nil
//
////    }
//}

//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//
//}
