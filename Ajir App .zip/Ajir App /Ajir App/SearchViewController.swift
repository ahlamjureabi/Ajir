//
//  SearchViewController.swift
//  Ajir App
//
//  Created by Ahlam Ahlam on 30/05/1443 AH.
//

import UIKit
import Firebase
class SearchViewController: UITableViewController {
}
    
    
